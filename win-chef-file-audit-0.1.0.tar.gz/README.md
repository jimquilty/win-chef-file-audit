# Example InSpec Profile

Checks for the presence of a file called chef.txt at the base level of the drive and that it's contents match "Chef is Great!"
